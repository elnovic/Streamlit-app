import streamlit as st
from config import APP_TITLE

st.set_page_config(page_title=APP_TITLE, layout="wide")

st.title(APP_TITLE)
st.write("Bienvenue sur le dashboard SING-ES")
