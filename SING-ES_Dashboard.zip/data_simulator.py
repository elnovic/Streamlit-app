import pandas as pd
import numpy as np

def generate_data(n=100):
    return pd.DataFrame({
        "Etudiants": np.random.randint(1000, 5000, n),
        "Professeurs": np.random.randint(100, 500, n)
    })
