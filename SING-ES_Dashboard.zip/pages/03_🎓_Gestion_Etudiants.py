import streamlit as st
st.title('Gestion Etudiants')