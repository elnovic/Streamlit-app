import streamlit as st
st.title('Gestion Administrative')