import streamlit as st
st.title('Formations & Accreditations')