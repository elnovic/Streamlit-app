APP_TITLE = "SING-ES Dashboard"
THEME = "light"
