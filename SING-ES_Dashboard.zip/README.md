# SING-ES Dashboard

Structure de base du projet Streamlit.

## Installation
pip install -r requirements.txt

## Lancement
streamlit run app.py
