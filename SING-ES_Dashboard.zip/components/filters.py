import streamlit as st

def select_filter(options, label):
    return st.selectbox(label, options)
